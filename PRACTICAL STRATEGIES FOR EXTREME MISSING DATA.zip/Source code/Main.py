#========================== IMPORT PACKAGES ============================

import pandas as pd
from sklearn.svm import SVC
from sklearn import preprocessing
from sklearn.model_selection import train_test_split 
from sklearn.metrics import confusion_matrix

#=========================== DATA SELECTION ============================

dataframe=pd.read_csv("Dementia.csv")
print("====================================================")
print("                     Data Selection                 ")
print("====================================================")
print()
print(dataframe.head(15))

#========================== PRE PROCESSING ================================

#====== checking missing values ========

print("====================================================")
print("         Before Handling Missing values             ")
print("====================================================")
print()
print(dataframe.isnull().sum())


print("====================================================")
print("         After Handling Missing Values             ")
print("====================================================")
print()
dataframe=dataframe.fillna(0)
print(dataframe.isnull().sum())

#0--dementia and 1--normal


#========= label encoding ===========

label_encoder = preprocessing.LabelEncoder() 

print("====================================================")
print("              Before Label Encoding                 ")
print("====================================================")
print()
print(dataframe['Category'].head(10))


print("====================================================")
print("              After Label Encoding                  ")
print("====================================================")
print()

dataframe['Category']= label_encoder.fit_transform(dataframe['Category'])

print(dataframe['Category'].head(10))

Label=['Sex','Hypertension','Stroke','Total_active']

dataframe[Label] = dataframe[Label].apply(label_encoder.fit_transform)

dataframe['BMI_category']= label_encoder.fit_transform(dataframe['BMI_category'].astype(str))

dataframe['Diabetes']= label_encoder.fit_transform(dataframe['Diabetes'].astype(str))

dataframe['Tri_200']= label_encoder.fit_transform(dataframe['Tri_200'].astype(str))

dataframe['HDL_40']= label_encoder.fit_transform(dataframe['HDL_40'].astype(str))

dataframe['Smoking_status']= label_encoder.fit_transform(dataframe['Smoking_status'].astype(str))

dataframe['Depression']= label_encoder.fit_transform(dataframe['Depression'].astype(str))

dataframe['Intellectual_1']= label_encoder.fit_transform(dataframe['Intellectual_1'].astype(str))

dataframe['Intellectual_2']= label_encoder.fit_transform(dataframe['Intellectual_2'].astype(str))


#========== drop unwanted columns ============

col=['Age_category','Education_category','Marital_status','Intellectual_3','Social_1','Social_2','Social_3','Recreational_1','Recreational_2','Recreational_3','Physical_1','Physical_2','Physical_3','Intellectually_active','Socially_active','Recreationally_active','Physically_active','Total_active']

dataframe=dataframe.drop(col,axis=1)


#========================== DATA SPLITTING ===========================


X=dataframe.drop(['Category'],axis=1)
y=dataframe['Category']


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

print("===============================================")
print("             Data Splitting                    ")
print("===============================================")
print()

print("Total no of data        :",dataframe.shape[0])
print("Total no of test data   :",X_test.shape[0])
print("Total no of train data  :",X_train.shape[0])

#========================== FEATURE SELECTION ==========================

import matplotlib.pyplot as plt

print("===============================================")
print("                    Correlation                ")
print("===============================================")
print()

import seaborn as sns
corr = dataframe.corr()
sns.heatmap(corr)
plt.show()
print()

#====================== CLASSIFICATION ===============================

#====== SVM =====

#initialize the model
svm = SVC(kernel="linear", C=0.1,random_state=0)

#fitting the model
svm.fit(X_train, y_train.ravel())

#predict the model
pred = svm.predict(X_test)



#========================== PERFORMANCE ANALAYSIS ================================

#===== confusion matrix ======

print("====================================================")
print("             Performance Analysis for SVM           ")
print("====================================================")
print()
cm1=confusion_matrix(y_test,pred)
print()
print("1.Confusion Matrix",cm1)
print()

TP = cm1[1][1]
FP = cm1[0][1]
FN = cm1[1][0]
TN = cm1[1][1]

Total=TP+FP+FN+TN

#Accuracy 
accuracy1=((TP+TN)/Total)*100
print("2.Accuracy:",accuracy1,'%')
print()

#Precision 
precision=TP/(TP+FP)*100
print("3.Precision:",precision,'%')
print()

#Sensitivity 
Sensitivity=TP/(TP+FN)*100
print("4.Sensitivity:",Sensitivity,'%')
print()

#specificity 
specificity = (TN / (TN+FP))*100
print("5.specificity:",specificity,'%')
print()


#==== RF ====

from sklearn.ensemble import RandomForestClassifier

regressor = RandomForestClassifier(n_estimators=20, random_state=0)

regressor.fit(X_train, y_train.ravel())

pred_rf=regressor.predict(X_test)

print("====================================================")
print("             Performance Analysis for RF           ")
print("====================================================")
print()
cm_rf=confusion_matrix(y_test,pred_rf)
print()
print("1.Confusion Matrix:",cm_rf)
print()

TP = cm_rf[1][1]
FP = cm_rf[0][1]
FN = cm_rf[1][0]
TN = cm_rf[1][1]

Total=TP+FP+FN+TN

#Accuracy 
accuracy_rf=((TP+TN)/Total)*100
print("2.Accuracy:",accuracy_rf,'%')
print()

#Precision 
precision=TP/(TP+FP)*100
print("3.Precision:",precision,'%')
print()

#Sensitivity 
Sensitivity=TP/(TP+FN)*100
print("4.Sensitivity:",Sensitivity,'%')
print()

#specificity 
specificity = (TN / (TN+FP))*100
print("5.specificity:",specificity,'%')
print()

#========================== PREDICTION ================================

print("====================================================")
print("                      Prediction                    ")
print("====================================================")
print()
for i in range(1,10):
    if pred_rf[i]== 0:
        print("============================")
        print()
        print([i],'Demented ')
    else:
        print("============================")
        print()
        print([i],'Non Demented ')

#============================= COMPARISON ===============================

print("====================================================")
print("                     Comaprison                     ")
print("====================================================")
print()
print()

import matplotlib.pyplot as plt
vals=[accuracy1,accuracy_rf]
inds=range(len(vals))
labels=["SVM ","RF" ]
fig,ax = plt.subplots()
rects = ax.bar(inds, vals)
ax.set_xticks([ind for ind in inds])
ax.set_xticklabels(labels)
plt.title('Comparison graph--Accuracy')
plt.show() 

